# THIS SCRIPT WILL LOGIN TO THE SPECIFIED VMWARE URL & FETCH THE NAME, CPU COUNT, MiB, AND POWER STATUS
# THIS SCRIPT WILL ALSO ORGANIZE AND STORE THE DATA IN A CSV FILE WHEN EXECUTED


import requests
from Cert import *
from secret import *
import urllib3
import pandas as pd
import csv

url = f'https://{Host}/api/session'
URL_vm = 'https://' + Host + '/api/vcenter/vm'
URL_cluster = 'https://' + Host + '/api/vcenter/cluster'

s = requests.Session()
# Make the login request
response = s.post(url, auth=({Username}, {Password}), verify=False).json()

# Get the session ID from the login response
session_id = response.json()['value']

# Gain access to VM list
get_auth = s.get(URL_vm, verify=False, headers={"vmware-api-session-id": {session_id}}).json()

# Set the session ID in the headers for future requests
headers['vmware-api-session-id'] = session_id

# Make the request to list the VMs
list_vms = requests.get(url=URL_vm, headers=headers)

# Get the list of VMs from the response
vms = list_vms.json()['value']

# Open a CSV file for writing the VM data
with open('usecase.csv', 'w', newline='') as csvfile:
    fieldnames = ['Name', 'Memory (bytes)', 'CPU Count', 'Power Status']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

    writer.writeheader()

    # Iterate through the list of VMs
    for vm in vms:
        # Set the URL for the VM's details endpoint
        vm_url_listed = URL_vm + vm['vm']

        # Make the request to get the VM's details
        vm_response = requests.get(url=vm_url_listed, headers=headers)

        # Get the VM's details from the response
        vm_details = vm_response.json()['value']

        # Get the VM's memory size in bytes
        memory_bytes = vm_details['summary']['config']['memory_size_MiB'] * 1024 * 1024

        # Get the VM's name
        name = vm_details['name']

        # Get the VM's CPU count
        cpu_count = vm_details['summary']['config']['num_cpu']

        # Get the VM's power status
        power_status = vm_details['summary']['runtime']['power_state']

writer.writerow({
    'Name': name,
    'Memory (bytes)': memory_bytes,
    'CPU Count': cpu_count,
    'Power Status': power_status
})
