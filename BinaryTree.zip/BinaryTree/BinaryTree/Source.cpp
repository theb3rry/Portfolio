#include <iostream>

using namespace std;

int b_search(int a[], int left, int right, int search)
{
	if (right >= left)
	{
		int middle = left + (right - left) / 2; // middle elements

		if (a[middle] == search) // if found
			return middle;

		if (a[middle] > search)
			return b_search(a, left, middle - 1, search);

		return b_search(a, middle + 1, right, search); // recursive function
	}
	return -1; // if not found
}

int main()
{
	int n = 20, search;
	int a[20];
	cout << "Enter 20 random numbers : ";
	for (int i = 0; i < n; i++)
	{
		cin >> a[i]; // read the array
	}
	cout << "What number are you looking for? ";
	cin >> search; // read the search Element
	int index = b_search(a, 0, n - 1, search); // call b_search()

	if (index == -1)
	{ // if not found
		cout << "\nElement not Found.";
	}
	else // if found
	{
		cout << "\nElement found at position: " << index;
	}


	return 0;
}