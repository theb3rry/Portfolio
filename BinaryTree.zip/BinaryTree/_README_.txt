This program is a C++ implementation of the binary search algorithm. 

1) It searches for a specific element in a sorted array of integers and returns the index of the element if it is found, or -1 if it is not found.

2) The program defines a function b_search that takes in an array, the left and right indices of the portion of the array to search, and the element to search for.
3) It performs a binary search to find the element in the array and returns the index where it is found.

4) In the main function, the program reads in 20 integers and stores them in an array. 
5) It then reads in the element to search for and calls the b_search function to search for it in the array. 
6) If the element is found, the index where it was found is printed. 
7) If it is not found, a message is printed saying that it was not found.