function getBotResponse(input) {
    //Automated response1
    input = input.toLowerCase();
    if (input == "Can I get help") {
        return "What can I help you with?";
    } else if (input == "how do I order pizza?") {
        return "Click on the headers";
    } else if (input == "How I pick my toppings") {
        return "Click on the customize button";
    }
     // Automated response3
   if (input == "i did not receive a receipt") {
        return "Please wait, as one of our cashier replys to your concern";
    } else if (input == "okay") {
        return "No problem, we can fix that for you!";
    } else if (input == "") {
        return "What kind of pizza did you order?";
    }

     // Automated response4
     if (input == "There was a mistake with my order") {
        return "No problem, we can fix that for you. What is the issue?";
    } else if (input == "I wanted the extra Cheese pizza") {
        return "No problem What the size you want your Cheese pizza?";
    } else if (input == "I wanted the large extra Cheese pizza")
        return "Ok, We have updated and will change your order for you free at charcge.";

        if (input == "There was a mistake with my order") {
            return "No problem, we can fix that for you. What is the issue?";
        } else if (input == "I wanted the extra Cheese pizza") {
            return "No problem What the size you want your Cheese pizza?";
        } else if (input == "I wanted the regular extra Cheese pizza")
            return "Ok, We have updated and will change your order for you free at charcge.";
    

     // Automated response5
     if (input == "There was a mistake with my order") {
        return "No problem, we can fix that for you. What is the issue?";
    } else if (input == "I wanted the pepperoni pizza") {
        return "No problem What the size you want your pepperoni pizza?";
    } else if (input == "I wanted the extra large pepperoni pizza")
        return "Ok, We have updated and will change your order for you free at charcge.";

        if (input == "There was a mistake with my order") {
            return "No problem, we can fix that for you. What is the issue?";
        } else if (input == "I wanted the pepperoni pizza") {
            return "No problem What the size you want your pepperoni pizza?";
        } else if (input == "I wanted the regular large pepperoni pizza")
            return "Ok, We have updated and will change your order for you free at charcge.";

     
     
        // Automated response6
     if (input == "There was a mistake with my order") {
        return "No problem, we can fix that for you. What is the issue?";
    } else if (input == "I wanted the supreme pizza") {
        return "No problem What the size you want your supreme pizza?";
    } else if (input == "I wanted the extra large supreme pizza")
        return "Ok, We have updated and will change your order for you free at charcge.";

        if (input == "There was a mistake with my order") {
            return "No problem, we can fix that for you. What is the issue?";
        } else if (input == "I wanted the supreme pizza") {
            return "No problem What the size you want your supreme pizza?";
        } else if (input == "I wanted the regular supreme pizza")
            return "Ok, We have updated and will change your order for you free at charcge.";

     // Simple responses7
     if (input == "There was a mistake with my order") {
        return "No problem, we can fix that for you. What is the issue?";
    } else if (input == "I wanted the sausage and bacon pizza") {
        return "No problem What the size you want your sausage and bacon pizza?";
    } else if (input == "I wanted the extra large sausage and bacon pizza")
        return "Ok, We have updated and will change your order for you free at charcge.";

        if (input == "There was a mistake with my order") {
            return "No problem, we can fix that for you. What is the issue?";
        } else if (input == "I wanted the sausage and bacon pizza") {
            return "No problem What the size you want your sausage and baconpizza?";
        } else if (input == "I wanted the regular sausage and bacon pizza")
            return "Ok, We have updated and will change your order for you free at charcge.";
    

     // Simple responses8
     if (input == "Can I change my curst type") {
        return "Sure thing, which of our two crust do you want?";
    } else if (input == "Thin crust") {
        return "Thank you, we have changed your curst to the Thin Crust";
    } else if(input == "thank you") {
        return "Have a wonderful day!";
    }

     // Simple responses9
     if (input == "Can I change my curst type") {
        return "Sure thing, which of our two crust do you want?";
    } else if (input == "Traditional crust") {
        return "Thank you, we have changed your curst to the Traditional Crust";
    } else if(input == "thank you") {
        return "Have a wonderful day!";
    }

     // Simple responses10
     if (input == "Can you send my receipt to my email?") {
        return "Yes, all of our transaction is sent to users email";
    } else if (input == "Thank you") {
        return "You are very welcome";
    } else if(input == "") {
        return "Is there anything else I can help you with?";
    }
    if (input == "hello") {
        return "Hello there!";
    } else if (input == "goodbye") {
        return "Talk to you later!";
    } else {
        return "Try asking something else!";
    }
}
