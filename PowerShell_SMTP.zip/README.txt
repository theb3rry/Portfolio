This script installs the SMTP Server feature on a virtual machine (VM), establishes a remote PowerShell session with the VM, and then sends an email using the SMTP Server on the VM.

The script contains four functions: InstallSMTP, StartSession, EnterSession, and firstEmail.

The InstallSMTP function uses the Invoke-VMScript cmdlet to import the Server Manager module and install the SMTP Server, Web Management Console, and WMI Web Services features on the VM.

The StartSession function creates a new remote PowerShell session with the VM using the New-PSSession cmdlet.

The EnterSession function connects to the

remote PowerShell session with the VM using the Enter-PSSession cmdlet.

The firstEmail function sends an email using the Send-MailMessage cmdlet, specifying the SMTP server and port to use.
Finally, the script sends another email using the Send-MailMessage cmdlet and prompts the user to enter their credentials.



