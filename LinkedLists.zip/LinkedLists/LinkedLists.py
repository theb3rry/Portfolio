class Node:
    def __init__(self, dataval=None):
        self.dataval = dataval
        self.nextNode = None

class studentnode:
    def __init__(self):
        self.headNode = None

# Print the linked list
    def listprint(self):
        printval = self.headNode
        while printval is not None:
            print (printval.dataval)
            printval = printval.nextNode
    def AtBegining(self,newdata):
        NewNode = Node(newdata)

# Update the new nodes next val to existing node
        NewNode.nextNode = self.headNode
        self.headNode = NewNode

list = berryLinkedList()
list.headNode = Node("Jan")
childNode = Node("Feb")
tailNode = Node("Mar")

list.headNode.nextNode = childNode
childNode.nextNode = tailNode

list.AtBegining("New Years")

list.listprint()