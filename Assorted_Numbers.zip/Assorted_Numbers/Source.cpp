#include <iostream>
#include <random>
#include <cstdlib>
#include <ctime>
#define MAX 100

// function headers to be used in programs
void get_rand_array(int[]);
void quick_sort(int[], int, int);
int partition(int[], int, int);
void swap(int*, int*);
void display_array(int[]);

using std::cin;
using std::cout;
using std::endl;

int main()
{
	//initialize an array of size MAX
	int rand_array[MAX];
	//fill array with random numbers
	get_rand_array(rand_array);
	//perform quick_sort on the array
	quick_sort(rand_array, 0, MAX - 1);
	cout << "Random Numbers Sorted!" << endl;
	//display content of the array
	display_array(rand_array);
	return 0;
}
//to generate random numbers array
void get_rand_array(int rand_array[])
{
	//set seed for random number
	srand(time(0));
	//generate MAX random elements in the range [0,100]
	for (int i = 0; i < MAX; i++)
	{
		rand_array[i] = rand() % 1000 + 1;
	}
	cout << "Random Numbers Generated!" << endl;
}

//to display all the random numbers in tha array
void display_array(int rand_array[])
{
	for (int i = 0; i < MAX; i++)
	{
		cout << rand_array[i] << " ";
	}
	cout << endl;
}

// to swap two numbers
void swap(int* a, int* b)
{
	int t = *a;
	*a = *b;
	*b = t;
}

/*
rand_array[] is the array containing random elements, left is starting index, that is 0,
and right is the last index of array.
*/
void quick_sort(int rand_array[], int left, int right)
{ // while there are more than 1 element perform quick sort
	if (left < right)
	{ //getting index for partition
		int parition_index = partition(rand_array, left, right);
		//divide the array into two by parition_index
		quick_sort(rand_array, left, parition_index - 1);
		quick_sort(rand_array, parition_index + 1, right);
	}
}

int partition(int rand_array[], int start, int end)
{
	// selecting last element as pivot
	int pivot = rand_array[end];
	// index of smaller element
	int i = (start - 1);

	for (int j = start; j <= end - 1; j++)
	{
		// If current element is smaller than or equal to pivot
		if (rand_array[j] <= pivot)
		{
			// increment index of smaller element
			i++;
			swap(&rand_array[i], &rand_array[j]);
		}
	}
	//swap the end and the current element
	swap(&rand_array[i + 1], &rand_array[end]);
	// return index to perform partition
	return (i + 1);
}