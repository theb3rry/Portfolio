The Quick Sort algorithm is a divide and conquer algorithm that works by selecting a "pivot" element from the array and partitioning the other elements into two sub-arrays according to whether they are less than or greater than the pivot. 
The sub-arrays are then sorted recursively using the same algorithm. This process continues until all the elements in the array are sorted.

The program defines several functions to perform these tasks:

1)The get_rand_array function generates the array of random integers and stores them in the rand_array parameter.
2)The display_array function displays all the elements in the rand_array parameter.
3)The swap function swaps the values of the two integers passed to it as pointers.
4)The quick_sort function performs the Quick Sort algorithm on the rand_array parameter between the left and right indices.
5)The partition function selects the pivot element and partitions the rand_array parameter between the start and end indices according to the pivot element.
6)In the main function, the program first generates the array of random integers and then calls the quick_sort function to sort it. 
7)It then displays the sorted array.