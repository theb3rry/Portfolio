import time
from telnetlib import EC

import selenium
from selenium import webdriver
import selenium.webdriver.common.by
import selenium.webdriver.support.ui
import selenium.webdriver.support

# Replace with the path to your ChromeDriver executable
from selenium.webdriver.support.wait import WebDriverWait

DRIVER_PATH = '/path/to/chromedriver'

# Initialize the ChromeDriver
driver = webdriver.Chrome(executable_path=DRIVER_PATH)

# Navigate to YouTube
driver.get('https://www.youtube.com/')

# Wait for the search input to be loaded
search_input = WebDriverWait(driver, 10).until(
    EC.presence_of_element_located((selenium.By.NAME, 'search_query'))
)

# Insert a topic into the search input
# search_input.send_keys('')

# Find the search button and click it
# search_button = driver.find_element_by_id('search-icon-legacy')
# search_button.click()

# Wait for the search results to be loaded
WebDriverWait(driver, 10).until(
    EC.presence_of_element_located((selenium.By.ID, 'video-title'))
)

# Find all the video elements on the page
videos = driver.find_elements_by_id('video-title')

# Select the first video (which should be the latest one)
videos.click()

# Wait for the video to start playing
time.sleep(30)

# Close the browser
driver.close()
